SITE 100% GRATUITO — Family's Burger (estático)

✅ Hospedagem grátis: GitHub Pages
✅ Domínio grátis: https://SEUUSUARIO.github.io (ou nome do repo)

COMO PUBLICAR (SEM PROGRAMAR):
1) Crie uma conta no GitHub
2) Crie um repositório chamado: SEUUSUARIO.github.io
3) Faça upload destes arquivos (index.html, menu.html, acompanhar.html, style.css, script.js, data.json)
4) Vá em Settings > Pages
   - Source: Deploy from a branch
   - Branch: main / root
5) Acesse: https://SEUUSUARIO.github.io

CONFIGURAR WHATSAPP:
- Abra data.json e troque "SEU_NUMERO_AQUI" pelo seu número no formato internacional:
  Exemplo Brasil: 5511999999999 (sem +, sem espaços)

EDITAR CARDÁPIO:
- Abra data.json e edite os itens em "menu" e os adicionais em "addons".

IMPORTANTE (pagamento):
Este site envia o pedido para o WhatsApp. Para Pix/cartão automático no site, aí já sai do “100% gratuito”
e precisa integrar gateway (geralmente pago/tarifas). Mas você pode cobrar Pix/cartão pelo link do Mercado Pago no WhatsApp.