const $ = (s)=>document.querySelector(s);
const $$ = (s)=>Array.from(document.querySelectorAll(s));

function money(v){ return v.toLocaleString('pt-BR',{style:'currency',currency:'BRL'}); }

async function loadData(){
  const res = await fetch('./data.json',{cache:'no-store'});
  return await res.json();
}

function waLink(number, text){
  // WhatsApp Click to Chat: https://wa.me/<number>?text=<encoded>
  return `https://wa.me/${number}?text=${encodeURIComponent(text)}`;
}

function groupBy(arr, key){
  return arr.reduce((acc, x)=>{ (acc[x[key]] ||= []).push(x); return acc; }, {});
}

function initHome(data){
  const waBtns = $$('.js-wa');
  waBtns.forEach(a=>{
    a.href = waLink(data.whatsapp_number, `Olá! Quero fazer um pedido no ${data.store_name}.`);
  });
  const nameEl = $('.js-store');
  if(nameEl) nameEl.textContent = data.store_name;
  const noteEl = $('.js-note');
  if(noteEl) noteEl.textContent = data.delivery_note;
}

function initMenu(data){
  initHome(data);

  const grouped = groupBy(data.menu, 'cat');
  const menuWrap = $('#menuWrap');
  const cart = {}; // id -> qty
  const addonState = {}; // id -> qty

  function render(){
    menuWrap.innerHTML = '';
    Object.keys(grouped).forEach(cat=>{
      const sec = document.createElement('div');
      sec.className = 'box';
      sec.innerHTML = `<h3>${cat}</h3><div class="sep"></div>`;
      grouped[cat].forEach(item=>{
        const qty = cart[item.id] || 0;
        const el = document.createElement('div');
        el.className = 'item';
        el.innerHTML = `
          <div>
            <strong>${item.name}</strong>
            <div class="notice">${item.desc}</div>
          </div>
          <div style="display:flex; flex-direction:column; align-items:flex-end; gap:8px;">
            <div class="price">${money(item.price)}</div>
            <div class="qty">
              <button data-act="dec" data-id="${item.id}">-</button>
              <div style="min-width:18px; text-align:center; font-weight:900;">${qty}</div>
              <button data-act="inc" data-id="${item.id}">+</button>
            </div>
          </div>
        `;
        sec.appendChild(el);
      });
      menuWrap.appendChild(sec);
    });

    // addons
    const addonsWrap = $('#addonsWrap');
    if(addonsWrap){
      addonsWrap.innerHTML = '';
      data.addons.forEach(a=>{
        const qty = addonState[a.id] || 0;
        const el = document.createElement('div');
        el.className = 'item';
        el.innerHTML = `
          <div>
            <strong>${a.name}</strong>
            <div class="notice">Opcional</div>
          </div>
          <div style="display:flex; flex-direction:column; align-items:flex-end; gap:8px;">
            <div class="price">${money(a.price)}</div>
            <div class="qty">
              <button data-aact="dec" data-id="${a.id}">-</button>
              <div style="min-width:18px; text-align:center; font-weight:900;">${qty}</div>
              <button data-aact="inc" data-id="${a.id}">+</button>
            </div>
          </div>
        `;
        addonsWrap.appendChild(el);
      });
    }

    const total = calcTotal();
    $('#total').textContent = money(total);
  }

  function calcTotal(){
    let t = 0;
    data.menu.forEach(i=> t += (cart[i.id]||0)*i.price);
    data.addons.forEach(a=> t += (addonState[a.id]||0)*a.price);
    return t;
  }

  function buildMessage(){
    const nome = ($('#nome').value||'').trim();
    const end = ($('#endereco').value||'').trim();
    const pag = ($('#pagamento').value||'').trim();
    const obs = ($('#obs').value||'').trim();

    const lines = [];
    lines.push(`🍔 *Pedido - ${data.store_name}*`);
    if(nome) lines.push(`👤 Cliente: ${nome}`);
    if(end) lines.push(`📍 Endereço: ${end}`);
    lines.push('');

    lines.push('*Itens:*');
    let hasItem = false;
    data.menu.forEach(i=>{
      const q = cart[i.id]||0;
      if(q>0){ hasItem=true; lines.push(`- ${q}x ${i.name} (${money(i.price)})`); }
    });
    if(!hasItem) lines.push('- (nenhum item selecionado)');

    let hasAddon = false;
    const addonLines = [];
    data.addons.forEach(a=>{
      const q = addonState[a.id]||0;
      if(q>0){ hasAddon=true; addonLines.push(`- ${q}x ${a.name} (${money(a.price)})`); }
    });
    if(hasAddon){
      lines.push('');
      lines.push('*Adicionais:*');
      lines.push(...addonLines);
    }

    lines.push('');
    lines.push(`💰 Total: *${money(calcTotal())}*`);
    if(pag) lines.push(`💳 Pagamento: ${pag}`);
    if(obs) lines.push(`📝 Obs: ${obs}`);

    lines.push('');
    lines.push('✅ Enviar este pedido e confirmar tempo de entrega.');

    return lines.join('\n');
  }

  document.addEventListener('click', (e)=>{
    const b = e.target.closest('button');
    if(!b) return;
    const id = b.dataset.id;
    if(b.dataset.act){
      cart[id] = cart[id] || 0;
      cart[id] += (b.dataset.act==='inc') ? 1 : -1;
      if(cart[id] < 0) cart[id]=0;
      render();
    }
    if(b.dataset.aact){
      addonState[id] = addonState[id] || 0;
      addonState[id] += (b.dataset.aact==='inc') ? 1 : -1;
      if(addonState[id] < 0) addonState[id]=0;
      render();
    }
  });

  $('#sendBtn').addEventListener('click', ()=>{
    const msg = buildMessage();
    const url = waLink(data.whatsapp_number, msg);
    window.open(url, '_blank', 'noopener');
  });

  render();
}

function initTrack(data){
  initHome(data);
  $('#trackBtn').addEventListener('click', ()=>{
    const id = ($('#pedido').value||'').trim();
    if(!id){ alert('Digite o número do pedido.'); return; }
    const msg = `Olá! Gostaria de acompanhar o pedido nº ${id} (${data.store_name}).`;
    window.open(waLink(data.whatsapp_number, msg), '_blank', 'noopener');
  });
}

window.addEventListener('DOMContentLoaded', async ()=>{
  const data = await loadData();
  initHome(data);

  if(document.body.dataset.page === 'menu') initMenu(data);
  if(document.body.dataset.page === 'track') initTrack(data);
});